 wxWidgets Autopackage
 =====================

 This directory contains the wxGTK autopackage of the latest
 stable release.

 An autopackage is an archive containing compiled binaries
 which aims to be distribution-neutral and as much as compatible
 as possible with linux systems.

 For more info see http://www.autopackage.org.


