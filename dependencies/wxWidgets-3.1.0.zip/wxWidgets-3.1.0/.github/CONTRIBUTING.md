# How to Contribute to wxWidgets

We appreciate receiving contributions and we have a community-maintained
[guide for contributors](http://wiki.wxwidgets.org/Development:_How_To_Contribute)
which explains everything you ever wanted to know for contributing to
wxWidgets.

You can either submit your [patches](http://trac.wxwidgets.org/wiki/HowToSubmitPatches)
to [wxTrac](http://trac.wxwidgets.org/newticket) or open GitHub pull requests,
depending on your preferences.

### Thanks in advance and looking forward to your contributions!
